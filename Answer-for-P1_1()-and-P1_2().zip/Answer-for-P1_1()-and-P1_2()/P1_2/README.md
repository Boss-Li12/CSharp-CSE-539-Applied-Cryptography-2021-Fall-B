# P1_2

## Submission
* Upload your `Program.cs` file to Gradescope. (The file needs to be named `Program.cs`)
* (if you are not using the stater code you need to make sure the `Namespace` and class name match the starter code)
* The autograder will run your code with different inputs 
* The autograder grades the output of the `P1_2()` function provided in the starter code on GitHub

## Instructions
* [P1 instructions](./P1%20instructions.pdf)

## Starter code
<!-- %20 is url encoding for spaces -->
* [P1_2 starter code (.NET 5)](./.NET%205.0/Program.cs)
* [vscode debugger (highly recommended)](../../gettingStarted/vscode_Debugger/P0) :lady_beetle: :star:
