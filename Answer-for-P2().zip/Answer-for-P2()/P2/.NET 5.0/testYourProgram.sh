#!/bin/sh

# example input given in the instructions
salt="C5"

# Instead of having to copy/paste the commented command below, you can just run this script from the command line ./testYourProgram.ps1
# dotnet run "C5"
# example output:
# AQJCMW0DGL,I95ORWB1A7

dotnet run $salt

